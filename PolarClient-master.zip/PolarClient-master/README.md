# PolarClient source code
Channel: Beta<br>
Last update: 06/15/2024
# Running it
Since this is the full source code you can easily run it by doing the following:
- Delete the old Polar if you bought it or account shared it. (`.minecraft/mods/ctjs-2.2.0-polar.jar`; `.minecraft/config/ChatTriggers/modules/PolarClient`)
- Downlod [CTJS for 1.8.9](https://www.chattriggers.com/#download) and put it in your mods folder.
- Click Code -> Download ZIP or click [here](https://github.com/aload-1/PolarClient/archive/refs/heads/master.zip).
- Unzip the zip and rename the `src` folder to `PolarClient`.
- Move the PolarClient folder to `.minecraft/config/ChatTriggers/modules`, so that `.minecraft/config/ChatTriggers/modules/PolarClient/metadata.json` exists.
- Launch the game.
# Donating 
If you want me to continue updating this, and feel like it, you can send me some money to any of these wallets:
- BTC `bc1q205h7qs4u83lyghc5pvm7v7nmtlrq498t35pwx`
- LTC `LRmAX3SPZNopQxZCdygTWehSssyT1wDZCU`
- SOL `5DA1yzW2DAm5yRza49BBnk2nyRFGQakibwBb4L9bTZd2`
